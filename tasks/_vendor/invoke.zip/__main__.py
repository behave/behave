#!/usr(bin/env python
# -*- coding: UTF-8 -*-
import os.path
import sys
HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)

if __name__ == "__main__":
    from invoke.main import program
    sys.exit(program.run())
